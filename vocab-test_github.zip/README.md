# vocab-test

This repository contains the *英文單字比賽練習系統* prepared for GitHub Pages.

## How to deploy
1. Create a repository named `vocab-test` in your GitHub account `jiushizhemefuyan-art`.
2. Upload all files from this package to the repository (you can drag & drop in the web UI or push via git).
3. Enable GitHub Pages in repository settings: Branch `main` (or `gh-pages`) → `/ (root)`.
4. Your site will be available at `https://jiushizhemefuyan-art.github.io/vocab-test/` shortly.

If you want, I can give you the exact git commands to run locally to push and publish.
